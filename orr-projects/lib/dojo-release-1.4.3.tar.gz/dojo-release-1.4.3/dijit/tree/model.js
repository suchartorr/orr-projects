/*
	Copyright (c) 2004-2009, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/


dojo.declare("dijit.tree.model",null,{destroy:function(){
},getRoot:function(_1){
},mayHaveChildren:function(_2){
},getChildren:function(_3,_4){
},isItem:function(_5){
},fetchItemByIdentity:function(_6){
},getIdentity:function(_7){
},getLabel:function(_8){
},newItem:function(_9,_a,_b){
},pasteItem:function(_c,_d,_e,_f){
},onChange:function(_10){
},onChildrenChange:function(_11,_12){
}});
